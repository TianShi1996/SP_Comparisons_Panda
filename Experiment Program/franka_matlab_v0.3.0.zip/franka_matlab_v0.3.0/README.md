# franka_matlab: Matlab & Simulink library for Franka Emika research robots

A Simulink & Matlab library and tools for the Franka Emika Robots based on the [Franka Control Interface (FCI)](https://frankaemika.github.io/docs/). See the [Franka Matlab Documentation](https://frankaemika.github.io/docs/franka_matlab/franka_matlab.html) for more information.