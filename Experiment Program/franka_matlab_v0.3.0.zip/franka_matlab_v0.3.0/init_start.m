%执行simulink前先初始化

%路径'/home/robot102/ST/franka_matlab_v0.3.0/'
% init_franka_matlab('/home/robot102/visp-ws/libfranka/')
init_franka_matlab('/home/robot102/visp-ws/libfranka/')