clear
close all
clc

load Kp_comp_bar.mat;
%%
color_a='#000000';color_b='#7E2F8E';color_c='#6E8B3D';%'#EEAD0E';
color_d='#0072BD';color_e='#CD3333';
color_f='#006400';color_g='#6B8E23';
color={color_a,color_b,color_c,color_d,color_e};


%%
ftsize=10;

% ss={'-s','-o','-d','->','-*'};
ss={'.-','.-','--','--','--'};
linwid=[1.6,1.6,2,2,1.8];

Kp_bar=[20,40,60,80,100,200]';
for k=1:length(Kp_bar)
    ind(k)=find(Kp_bar(k)==Kp);
end
Kp(ind)
RMSE_bar=RMSE_Task2(ind,:);
Wss_bar=WssData(ind,:);
Pre_ss_bar=PressData(ind,:);

close all
clc
h0=figure(1);set(h0,'Position',[100,400,560,150*2]);

subplot(211)
b=bar(RMSE_bar);
for k=1:5
    b(k).FaceColor=color{k};
end
ylim([0,1e-2])
xlabel('');
ylabel('RMSE({\boldmath$e_1$})','Interpreter','latex','FontSize',ftsize);
legend('Controller A','Controller B','Controller C','Controller D','Controller E',...
    'Interpreter','latex','FontSize',8,'Box','off','NumColumns',2);
text(-0.3,1e-2,'(a)','Interpreter','latex','FontName','Times New Roman','FontSize',ftsize)
set(gca,'XTickLabel',num2str(Kp_bar),'FontName','Times New Roman','FontSize',ftsize)

subplot(212)
b=bar(Pre_ss_bar);
for k=1:3
    b(k).FaceColor=color{k+2};
end
ylim([0,0.2])
xlabel('$K_p$','Interpreter','latex','FontSize',ftsize);
ylabel('$\epsilon_{\rm{ss}}$','Interpreter','latex','FontSize',ftsize);
% ylabel('$\tilde W_{\rm{ss}}$','Interpreter','latex','FontSize',ftsize);
legend('Controller C','Controller D','Controller E',...
    'Interpreter','latex','FontSize',8,'Box','off','NumColumns',1);
text(-0.3,0.2,'(b)','Interpreter','latex','FontName','Times New Roman','FontSize',ftsize)
set(gca,'XTickLabel',num2str(Kp_bar),'FontName','Times New Roman','FontSize',ftsize)

print('sim_kp_bar.eps','-depsc');















