function SP_fig1(figk,Ctrl,color,ind)
% plot one sub-fig
linwid=[2.3,2.3,2.3,2.3,2.2,1.6];Ts=0.0002;
[~,len]=size(Ctrl);ss={'-','-','-.','-.','--','--'};
h0=figure(figk);set(h0,'Position',[100,400,560,150]);
ftsize=12;

wlab={'$\|\tilde{W}\|$\, ','$\|\tilde{W}_e\|$ ','$\|\tilde{W}\|$\, '};

for k=3:len
    plot(Ctrl(k).err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    ModName{k}=['by Controller ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end


legend(ModName{3},ModName{4},ModName{5},'Interpreter','latex','FontSize',8','Box','off','NumColumns',1);
% xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
xlabel('');
ylabel('$\|\tilde{W}\|$, $\|\tilde{W}_{\rm{e}}\|$','Interpreter','latex','FontSize',ftsize);
% ylabel('Estimate Error','Interpreter','latex','FontSize',ftsize)
text(-3.5*4,4,'(a)','Interpreter','latex','FontSize',ftsize)
% ylabel('Parameter Estimate Errors','Interpreter','latex','FontSize',ftsize);
title('');
axis([0,100,0,4]);xticks(0:20:100);
% text(5,3,['$K_p=$',num2str(ind)],'Interpreter','latex','FontSize',ftsize)
set(gca,'FontName','Times New Roman','FontSize',ftsize);
% axes('Position',[0.35,0.35,0.5,0.3]);
% for k=3:len
%     plot(Ctrl(k).err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
% end
% xlabel('');ylabel('');title('');
% axis([70,100,0,0.1]);
% set(gca,'FontName','Times New Roman','FontSize',12);

print('W_error.eps','-depsc');
