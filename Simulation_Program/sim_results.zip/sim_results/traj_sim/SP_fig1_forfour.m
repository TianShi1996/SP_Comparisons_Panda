function SP_fig1_forfour(figk,Ctrl,color)

% plot one sub-fig
linwid=[2.6,2.6,2.3,2.3,2.2,1.6];Ts=0.0002;
[~,len]=size(Ctrl);
h0=figure(figk);set(h0,'Position',[1000,100,560*1,160*4]);
ymax1=3e-3;ymax2=1e-3;ss={'-','-','-.','-.','--','--'};
ftsize=10;
%% W_tilde
subplot(411)
for k=3:len
    plot(Ctrl(k).err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    ModName{k}=['Controller ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end
legend(ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off');
xlabel('');ylabel('$\|\tilde{W}\|$, $\|\tilde{W}_e\|$','Interpreter','latex','FontSize',ftsize);
title('');
axis([0,100,0,4]);xticks(0:20:100);
text(-3.5*4,4,'(a)','Interpreter','latex','FontSize',ftsize)
set(gca,'FontName','Times New Roman','FontSize',ftsize);

%% tau_a
subplot(412);
for k=1:len
%     tau=Ctrl(k).tau_a.Data;
%     tau_a=errvec(reshape(tau,7,500001,[])');
    plot(Ctrl(k).tau_a,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    ModName{k}=['Controller ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end
legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',2);
xlabel('');
ylabel('{\boldmath$\|\tau_a\|$} (N.m)','Interpreter','latex','FontSize',ftsize);
title('');axis([0,25,0,100]);
text(-3.5,100,'(b)','Interpreter','latex','FontSize',ftsize)
set(gca,'FontName','Times New Roman','FontSize',ftsize);
axes('Position',[0.25,0.63,0.25,0.06]);
for k=1:len
    plot(Ctrl(k).tau_a,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    %ModName{k}=['Ctrl ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end
xlabel('');ylabel('');title('');
axis([5.7,6.4,44.3,45.1]);
set(gca,'FontName','Times New Roman','FontSize',10);

%% q_error
subplot(413)
ymax1=1.5e-2;ymax2=6e-3;
%axes('Position',[0.25,0.6,0.4,0.25]);
for k=1:len
    plot(Ctrl(k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
end
xlabel('');
ylabel('{\boldmath$\|e_1\|$} (rad)','Interpreter','latex','FontSize',ftsize);title('');
text(-3.5,ymax1,'(c)','Interpreter','latex','FontSize',ftsize)
axis([0,25,0,ymax1]);
legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',2);
set(gca,'FontName','Times New Roman','FontSize',ftsize);
subplot(414)
%axes('Position',[0.25,0.25,0.4,0.25]);
for k=1:len
    plot(Ctrl(k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
end
xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
ylabel('{\boldmath$\|e_1\|$} (rad)','Interpreter','latex','FontSize',ftsize);title('');
text(75-3.5,ymax2,'(d)','Interpreter','latex','FontSize',ftsize)
axis([75,100,0,ymax2]);
legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',2);
set(gca,'FontName','Times New Roman','FontSize',ftsize);


print('fig_sim1_short.eps','-depsc');



