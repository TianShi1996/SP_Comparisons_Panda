function SP_fig1_pre_err(figk,Ctrl,color,ind)
% plot one sub-fig
linwid=[2.3,2.3,2.3,2.3,2.2,1.6];Ts=0.0002;
[~,len]=size(Ctrl);
h0=figure(figk);set(h0,'Position',[100,400,560,150]);
ymax1=2;ymax2=0.15;ss={'-','-','-.','-.','--','--'};
ftsize=12;


h=figure(figk);set(h,'Position',[100,400,560,150]);
%axes('Position',[0.25,0.6,0.4,0.25]);
for k=3:len
    plot(Ctrl(k).predict_err,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    ModName{k}=['by Controller ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end
% xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
xlabel('');
ylabel('{\boldmath$\|\epsilon\|$} (N.m)','Interpreter','latex','FontSize',ftsize);title('');
text(-3.5,10,'(e)','Interpreter','latex','FontSize',ftsize)
% axis([0,30,0,ymax1]);
xlim([0,25]);
legend(ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',1);
set(gca,'FontName','Times New Roman','FontSize',ftsize);

print('pre_err1.eps','-depsc');

% axes('Position',[0.22,0.45,0.35,0.27]);
% for k=3:len
%     plot(Ctrl(k).predict_err,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
%     ModName{k}=['by Controller ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
% end
% xlabel('');ylabel('');title('');
% axis([0,25,0,0.5]);
% set(gca,'FontName','Times New Roman','FontSize',12);

h=figure(figk+1);set(h,'Position',[100,400,560,170]);
%axes('Position',[0.25,0.25,0.4,0.25]);
for k=3:len
    plot(Ctrl(k).predict_err,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
end
xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
ylabel('{\boldmath$\|\epsilon\|$} (N.m)','Interpreter','latex','FontSize',ftsize);title('');
text(75-3.5,ymax2,'(f)','Interpreter','latex','FontSize',ftsize)
axis([75,100,0,ymax2]);
legend(ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',1);
set(gca,'FontName','Times New Roman','FontSize',ftsize);

print('pre_err2.eps','-depsc');
