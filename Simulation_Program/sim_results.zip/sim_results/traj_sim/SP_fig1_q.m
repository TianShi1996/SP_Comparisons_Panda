function SP_fig1_q(figk,Ctrl,color,ind)
% plot one sub-fig
linwid=[2.3,2.3,2.3,2.3,2.2,1.6];Ts=0.0002;
[~,len]=size(Ctrl);
h0=figure(figk);set(h0,'Position',[100,400,560,150]);
ymax1=3e-3;ymax2=2e-3;ss={'-','-','-.','-.','--','--'};
ftsize=12;
for k=1:len
    plot(Ctrl(k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    ModName{k}=['by Controller ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end


legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',1);
% xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
xlabel('');
ylabel('{\boldmath$\|e_1\|$} (rad)','Interpreter','latex','FontSize',ftsize);title('');

xlim([0,100]);xticks(0:30:150);
set(gca,'FontName','Times New Roman','FontSize',ftsize);
% text(5,3,['$K_p=$',num2str(ind)],'Interpreter','latex','FontSize',ftsize)

h=figure(figk+1);set(h,'Position',[100,400,560,150]);
%axes('Position',[0.25,0.6,0.4,0.25]);
for k=1:len
    plot(Ctrl(k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
end
% xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
xlabel('');
ylabel('{\boldmath$\|e_1\|$} (rad)','Interpreter','latex','FontSize',ftsize);title('');
text(-3.5,3e-3,'(c)','Interpreter','latex','FontSize',ftsize)
axis([0,25,0,ymax1]);legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',1);
set(gca,'FontName','Times New Roman','FontSize',ftsize);

print('q_error1.eps','-depsc');

h=figure(figk+2);set(h,'Position',[100,400,560,150]);
%axes('Position',[0.25,0.25,0.4,0.25]);
for k=1:len
    plot(Ctrl(k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
end
% xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
xlabel('');
ylabel('{\boldmath$\|e_1\|$} (rad)','Interpreter','latex','FontSize',ftsize);title('');
text(75-3.5,2e-3,'(d)','Interpreter','latex','FontSize',ftsize)
axis([75,100,0,ymax2]);legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',1);
set(gca,'FontName','Times New Roman','FontSize',ftsize);

print('q_error2.eps','-depsc');
