function SP_fig_q(figk,Ctrl,color,Pos,ind)
linwid=[3,3,2,1.2,1.5,1.2];Ts=0.0002;
[~,len]=size(Ctrl);
h0=figure(figk);set(h0,'Position',[1000,400,560,460]);
ymax=[3e-3,2e-3,1e-3];ss={'-','-','-.','--','-.','--'};
for i=3:-1:1
    h=subplot(3,1,i);set(h,'Position',Pos(i,:))
    for k=1:len
        plot(Ctrl(i,k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
        ModName{k}=['Controller ',Ctrl(i,k).SimulationMetadata.ModelInfo.ModelName(end)];
    end
    
    if i==1
        legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},ModName{6},'FontSize',10);
    end
    ylabel('$\|q-q_d\|$','Interpreter','latex','FontSize',16);title('');
    axis([0,105,0,0.06]);
    if i~=3
        xticks('');xlabel(''); 
    end
    text(5,3,['$K_p=$',num2str(ind(i))],'Interpreter','latex','FontSize',16)

%     axes('Position',[0.15,0.75-0.3*(i-1),0.3,0.15]);
%     for k=1:len
%         plot(Ctrl(i,k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
%     end
%     xlabel('');ylabel('');title('');
%     axis([10,30,0,ymax(i)]);
% 
%     axes('Position',[0.5,0.75-0.3*(i-1),0.3,0.15]);
%     for k=1:len
%         plot(Ctrl(i,k).q_err_norm,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
%     end
%     xlabel('');ylabel('');title('');
%     axis([80,100,0,ymax(i)]);
end


