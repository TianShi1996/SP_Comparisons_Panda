function SP_fig_tau_a(figk,Ctrl,color,ind)
% plot one sub-fig
linwid=[2.3,2.3,2.3,2.3,2.2,1.6];Ts=0.0002;
[~,len]=size(Ctrl);ss={'-','-','-.','-.','--','--'};
h0=figure(figk);set(h0,'Position',[100,400,560,150]);
ftsize=12;
for k=1:len
%     tau=Ctrl(k).tau_a.Data;
%     tau_a=errvec(reshape(tau,7,500001,[])');
    plot(Ctrl(k).tau_a,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    ModName{k}=['by Controller ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end


legend(ModName{1},ModName{2},ModName{3},ModName{4},ModName{5},'FontSize',8,'Box','off','NumColumns',1);
% xlabel('Time (s)','Interpreter','latex','FontSize',ftsize);
xlabel('');
ylabel('{\boldmath$\|\tau_{\rm{a}}\|$} (N.m)','Interpreter','latex','FontSize',ftsize);
text(-3.5,100,'(b)','Interpreter','latex','FontSize',ftsize)
% ylabel('Parameter Estimate Errors','Interpreter','latex','FontSize',ftsize);
title('');
axis([0,25,0,100]);
% text(5,3,['$K_p=$',num2str(ind)],'Interpreter','latex','FontSize',ftsize)
set(gca,'FontName','Times New Roman','FontSize',ftsize);
axes('Position',[0.25,0.65,0.25,0.2]);
for k=1:len
    plot(Ctrl(k).tau_a,ss{k},'color',color{k},'linewidth',linwid(k));hold on;
    ModName{k}=['Ctrl ',Ctrl(k).SimulationMetadata.ModelInfo.ModelName(end)];
end
xlabel('');ylabel('');title('');
axis([6.1,6.3,44.8,44.86]);
set(gca,'FontName','Times New Roman','FontSize',10);


print('tau_a.eps','-depsc');
