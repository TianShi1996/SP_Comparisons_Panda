function err_norm=errvec(u)

err_norm=sqrt(sum(u.^2,2));
