%% Simulation comparisons with Kp=100
clear
close all
clc
%%
load comp1_traj2_Kp100.mat;


%%
color_a='#000000';color_b='#7E2F8E';color_c='#6E8B3D';%'#EEAD0E';
color_d='#0072BD';color_e='#CD3333';
color_f='#006400';color_g='#6B8E23';
linwid=1.2;

%% comp: Kp=20*I; taud=23;
clc
close all
Pos=zeros(3,4);
for k=3:-1:1
    Pos(k,:)=[0.10,0.98-k*7*0.13/3,0.88,0.12*7/3];
end
color={color_a,color_b,color_c,color_d,color_e,color_f};
close all

figk=1;figqk=2;

Ctrl100=[CtrlA_traj2_Kp100,CtrlB_traj2_Kp100,CtrlC_traj2_Kp100,CtrlD_traj2_Kp100,CtrlE_traj2_Kp100];

Ctrl=Ctrl100;ind=100;kp=1;

% SP_fig1(figk,Ctrl(kp,:),color,ind(kp))
% SP_fig1_q(figqk,Ctrl(kp,:),color,ind(kp))
% SP_fig_tau_a(5,Ctrl(kp,:),color,ind(kp))
% SP_fig1_pre_err(6,Ctrl(kp,:),color,ind(kp))
% SP_fig1_forsix(figk,Ctrl,color)
SP_fig1_forfour(figk,Ctrl,color)